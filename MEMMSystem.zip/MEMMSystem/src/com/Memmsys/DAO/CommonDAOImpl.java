/**
 * 
 */
package com.Memmsys.DAO;

import java.util.List;

import org.hibernate.Query;

import com.Memmsys.DAOInterfc.CommonDAO;
import com.Memmsys.database.MateAndinstor;

/**
 * @author wangyao
 *
 */
public class CommonDAOImpl extends BaseDAOImpl< MateAndinstor>implements CommonDAO {
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getAllTest() {
		String hql="select m.miname,m.moneyl,m.allmoney from MateAndinstor as m where instorage.id=inId";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		//list�б�����Ƕ������鼴Object[].class������
		List<Object>list=query.list();
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<MateAndinstor> getAllByOut() {
		// TODO �Զ����ɵķ������
		String hql="from MateAndinstor where outstorages.id=outId ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		return query.list();
	}

	@Override
	public void updateByid(String string, MateAndinstor mi) {
		// TODO �Զ����ɵķ������
		String hql="update MateAndinstor as m set m.miname=?,m.moneyl=?,m.allmoney=?,m.maccount=?,m.hname=? where m.miId=? ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, mi.getMiname());
		query.setLong(1, mi.getMoneyl());
		query.setLong(2, mi.getAllmoney());
		query.setParameter(3, mi.getMaccount());
		query.setParameter(4, mi.getHname());
		query.setParameter(5, Integer.parseInt(string));
		query.executeUpdate();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object> getByName(String string) {
		// TODO �Զ����ɵķ������
		String hql="select m.maccount from MateAndinstor as m where miname=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, string);
		return query.list();
	}

	@Override
	public List<MateAndinstor> getMates(String hname) {
		// TODO �Զ����ɵķ������
		String hql="select m.miname from MateAndinstor as m where m.hname=? ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, hname);
		if (query.list()!=null) {
			return query.list();
		}
		return null;
	}


}
