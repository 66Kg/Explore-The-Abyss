/**
 * 
 */
package com.Memmsys.DAO;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;

import com.Memmsys.DAOInterfc.BaseDAO;

/**
 * @author wangyao
 *
 */
public class BaseDAOImpl<T> implements BaseDAO<T>{

	//��ΪSpring �Ѿ��������session�����ɷ�ʽ��������session
	private SessionFactory sessionFactory;

    Class<T> clazz;
    ParameterizedType pt;
    @SuppressWarnings("unchecked")
	public BaseDAOImpl(){
    	pt=(ParameterizedType)this.getClass().getGenericSuperclass();
    	clazz=(Class<T>)pt.getActualTypeArguments()[0];
    }
	/**
	 * @return sessionFactory
	 */
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	/**
	 * @param sessionFactory Ҫ���õ� sessionFactory
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/**
	 * @return session
	 */


	@Override
	public void add(T t) {
		// TODO �Զ����ɵķ������
		this.getSessionFactory().getCurrentSession().save(t);
	}

	@Override
	public void delete(T t) {
		// TODO �Զ����ɵķ������
		this.getSessionFactory().getCurrentSession().delete(t);
	}

	@Override
	public void update(T t) {
		// TODO �Զ����ɵķ������
		this.getSessionFactory().getCurrentSession().update(t);
	}

	@SuppressWarnings("unchecked")
	@Override
	public T get(Serializable id) {
		// TODO �Զ����ɵķ������
		
		return (T)this.getSessionFactory().getCurrentSession().get(clazz,id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAll() {
		// TODO �Զ����ɵķ������
		
		return getSessionFactory().getCurrentSession().createQuery("from " + clazz.getSimpleName()).list();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<T> getListByHQL(String hqString, Object... value) {
		// TODO �Զ����ɵķ������
		Query query=this.getSessionFactory().getCurrentSession().createQuery(hqString);
		if(value!=null){
			for (int i = 0; i < value.length; i++) {
				query.setParameter(i, value[i]);				
			}
		}
		return query.list();
	}

	
}
