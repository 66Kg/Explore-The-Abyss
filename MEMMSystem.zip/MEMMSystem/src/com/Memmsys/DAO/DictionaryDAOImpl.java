/**
 * 
 */
package com.Memmsys.DAO;

import java.util.List;

import org.hibernate.Query;

import com.Memmsys.DAOInterfc.DictionaryDAO;
import com.Memmsys.database.Dictionary;

/**
 * @author wangyao
 *
 */
public class DictionaryDAOImpl extends BaseDAOImpl<Dictionary>implements DictionaryDAO {

	@SuppressWarnings("unchecked")
	@Override
	public List<Dictionary> getByName(String name) {
		// TODO �Զ����ɵķ������
		String hql="select d from Dictionary as d where d.ename=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, name);
		return query.list();
	}

	@Override
	public void updateByName(Dictionary dictionary) {
		// TODO �Զ����ɵķ������
		String hql="update Dictionary set eename=?,eground=?,euse=?,espec=?,epeople=?,ebadside=?where ename=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, dictionary.getEename());
		query.setParameter(1, dictionary.getEground());
		query.setParameter(2, dictionary.getEuse());
		query.setParameter(3, dictionary.getEspec());
		query.setParameter(4, dictionary.getEpeople());
		query.setParameter(5, dictionary.getEbadside());
		query.setParameter(6, dictionary.getEname());
		query.executeUpdate();
	}
}
