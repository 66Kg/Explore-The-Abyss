/**
 * 
 */
package com.Memmsys.DAO;

import org.hibernate.Query;
import com.Memmsys.DAOInterfc.ManagerDAO;
import com.Memmsys.database.Manager;

/**
 * @author wangyao
 *
 */
public class ManagerDAOImpl extends BaseDAOImpl<Manager> implements ManagerDAO {
	//ʵ�ֽӿ��еķ���
	@SuppressWarnings("unchecked")
	@Override
	public Manager findByNP(Manager manager) {
	
		// TODO �Զ����ɵķ������
		String sql="from Manager where name=? and password=?";
		Query query=getSessionFactory().openSession().createQuery(sql);
		query.setString(0, manager.getName());
		query.setString(1, manager.getPassword());
		java.util.List<Manager>manList=query.list();
		if(manList.size()>0){
			System.out.println(manList.get(0));
			return manList.get(0);
		}
		return null;
	}

}
