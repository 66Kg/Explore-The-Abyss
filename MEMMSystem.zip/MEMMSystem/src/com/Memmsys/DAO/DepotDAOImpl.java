/**
 * 
 */
package com.Memmsys.DAO;

import java.util.List;

import org.hibernate.Query;

import com.Memmsys.DAOInterfc.DepotDAO;
import com.Memmsys.database.Depot;

/**
 * @author wangyao
 *
 */
public class DepotDAOImpl extends BaseDAOImpl< Depot>implements DepotDAO {

	@SuppressWarnings("unchecked")
	@Override
	public List<Depot> getByName(String mname) {
		// TODO �Զ����ɵķ������
		String hql="select d from Depot as d where dname=? ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setString(0, mname);
		return query.list();
	}

	@Override
	public void updateDepot(Depot depot) {
		// TODO �Զ����ɵķ������
		String hql="update Depot set daccount=? where dname=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		/*query.setParameter(0, materials.getMaccount());*/
		query.setParameter(0, depot.getDaccount());
		query.setParameter(1, depot.getDname());
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Depot> getAllDepot() {
		// TODO �Զ����ɵķ������
		String hql="select d from Depot as d";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		return query.list();			 
	}
}
