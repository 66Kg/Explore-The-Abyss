/**
 * 
 */
package com.Memmsys.DAO;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;

import com.Memmsys.DAOInterfc.OutstorageDAO;
import com.Memmsys.database.Outstorage;

/**
 * @author wangyao
 *
 */
public class OutstorageDAOImpl extends BaseDAOImpl<Outstorage>implements OutstorageDAO {

	@Override
	public List<Object> getAllBynumber(String outnum) {
		String hql="select o.outtime,o.outaccount,o.outmoney,o.outperson,o.outreason,o.outname.miname from Outstorage as o where outNum=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setString(0, outnum);	
		//list�б�����Ƕ������鼴Object[].class������
		List<Object[]>list=query.list();
		//value�б�����ǲ�ѯ���Ķ���
		Object[]values=list.get(0);	
		//���������Ա������浽newlist��
		List<Object>newlist=new ArrayList<Object>();
		for (int i = 0; i < values.length; i++) {
			newlist.add(values[i]);
		}
		if(newlist!=null){
			return newlist;
		}
		return null;	
	}

	@Override
	public void delete(Integer num) {
		// TODO �Զ����ɵķ������
		String hql="delete Outstorage o where o.outnum=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, num);
		query.executeUpdate();
	}

	@Override
	public void deleteBynum(Outstorage outstorage) {
		// TODO �Զ����ɵķ������
		String hql="delete Outstorage o where o.outnum=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, outstorage.getOutnum());
		query.executeUpdate();
	}

	@Override
	public int getMid(int parseInt) {
		// TODO �Զ����ɵķ������
		String hql="select o.material.mId from Outstorage as o where o.outnum=?  ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, parseInt);
		return (Integer) query.list().get(0);
	}

	@Override
	public int getByMnumber(int i) {
		// TODO �Զ����ɵķ������
		String hql="select o.outaccount from Outstorage as o where material.number=?  ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, i);
		int sum=0;

		if (query.list()!=null) {
			for (int j = 0; j < query.list().size(); j++) {
			int l=(Integer)query.list().get(j);
				sum+=l;
			}
			
			return sum;
		}
		return 0;
	}
}
