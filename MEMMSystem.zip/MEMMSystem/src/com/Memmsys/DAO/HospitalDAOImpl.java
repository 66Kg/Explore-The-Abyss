	/**
 * 
 */
package com.Memmsys.DAO;

import org.hibernate.Query;
import com.Memmsys.DAOInterfc.HospitalDAO;
import com.Memmsys.database.Hospital;

/**
 * @author wangyao
 *
 */
public class HospitalDAOImpl extends BaseDAOImpl<Hospital> implements HospitalDAO {
	@Override
	public void updateByid(Hospital hospital) {
		// TODO �Զ����ɵķ������
		String hql="update Hospital set hname=?,haddress=?,howner=?,hphoneString=?where hnumber=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0,hospital.getHname());
		query.setParameter(1,hospital.getHaddress());
		query.setParameter(2, hospital.getHowner());
		query.setParameter(3,hospital.getHphoneString());
		query.setParameter(4,hospital.getHnumber());
		query.executeUpdate();
	}

	@Override
	public void deleteByNum(Hospital hospital) {
		// TODO �Զ����ɵķ������
		String hql="delete Hospital as h where h.hnumber=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0,hospital.getHnumber());
		query.executeUpdate();
	}	
}



