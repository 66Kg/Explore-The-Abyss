/**
 * 
 */
package com.Memmsys.DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;

import com.Memmsys.DAOInterfc.InstorageDAO;
import com.Memmsys.database.Instorage;

/**
 * @author wangyao
 *
 */
public class InstorageDAOImpl extends BaseDAOImpl< Instorage> implements InstorageDAO{
	
	@Override
	public List<Object>getAllBynumber(String innum){
		String hql="select i.intime,i.inaccount,i.inperson,m.miname,m.moneyl,m.allmoney,m.miId from Instorage as i, MateAndinstor as m where inNum=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0,Integer.parseInt(innum));	
		//list�б�����Ƕ������鼴Object[].class������
		List<Object[]>list=query.list();
		//value�б�����ǲ�ѯ���Ķ���
		Object[]values=list.get(0);	
		//���������Ա������浽newlist��
		List<Object>newlist=new ArrayList<Object>();
		for (int i = 0; i < values.length; i++) {
			newlist.add(values[i]);
		}
		if(newlist!=null){
			return newlist;
		}
		return null;	
	}

	@Override
	public List<Object> getAllInstor() {
		// TODO �Զ����ɵķ������
		String hql="from Instorage as i where mateAndinstor.id=miId";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		List<Object[]>list=query.list();
		Object[]values=list.get(0);
		List<Object>newList=new ArrayList<Object>();
		for (int i = 0; i < values.length; i++) {
			newList.add(values[i]);						
		}
		System.out.println(newList);
		if (list!=null) {
			return newList;
		}
		return null;
	}

	@Override
	public void updateByNum(Instorage instorage) {
		// TODO �Զ����ɵķ������
		String sql="update Instorage as i set i.intime=?,i.inaccount=?,i.inperson=? where i.innum=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(sql);
		query.setParameter(0, instorage.getIntime());
		query.setParameter(1, instorage.getInaccount());
		query.setParameter(2, instorage.getInperson());
		query.setParameter(3, instorage.getInnum());
		query.executeUpdate();
		/*getSessionFactory().getCurrentSession().getTransaction().commit();*/
	}

	@Override
	public void deleteByName(Instorage instorage) {
		// TODO �Զ����ɵķ������
		String hql="delete Instorage i where i.innum=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, instorage.getInnum());
		query.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public int getMid(int parseInt) {
		// TODO �Զ����ɵķ������
		String hql="select i.material.mId from Instorage as i where i.innum=?  ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, parseInt);
		return (Integer) query.list().get(0);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Instorage> getByNum(int parseInt) {
		// TODO �Զ����ɵķ������
		String hql="select i from Instorage as i where i.material.number=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, parseInt);
		return query.list();
	}
	
}
