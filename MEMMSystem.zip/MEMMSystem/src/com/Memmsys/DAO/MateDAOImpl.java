/**
 * 
 */
package com.Memmsys.DAO;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;

import com.Memmsys.DAOInterfc.MateDAO;
import com.Memmsys.database.Depot;
import com.Memmsys.database.Instorage;
import com.Memmsys.database.Material;
import com.Memmsys.database.Outstorage;

/**
 * @author wangyao
 *
 */
public class MateDAOImpl extends BaseDAOImpl<Material>implements MateDAO{

	@Override
	public void updateByNum(String mnumber, Material materials) {
		// TODO �Զ����ɵķ������
		String hql="update Material set maccount=?,mname=?,mmodel=?,mtype=? where mnumber=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		/*query.setParameter(0, materials.getMaccount());*/
		query.setParameter(1, materials.getMname());
		/*query.setParameter(2, materials.getMmodel());*/
		query.setParameter(3, materials.getMtype());
		query.setParameter(4, mnumber);
		query.executeUpdate();
	}

	@Override
	public List<Material> getByName(String mname) {
		// TODO �Զ����ɵķ������
		String hql="select m from Material as m where mname=? ";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setString(0, mname);
		return query.list();
	}

	@Override
	public List<Object> getOver() {
		// TODO �Զ����ɵķ������
		String hql="select m.muyear from Material as m";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		List<Object>list=query.list();
		if (list!=null) {
			return list;
		}
		return null;
	}

	@Override
	public List<Object> getOverInfo(Date date) {
		// TODO �Զ����ɵķ������
		String hql="select m.mname,m.maccount from Material as m where  m.muyear=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, date);
		List<Object>list=query.list();
		if (list!=null) {
			return list;
		}
		return null;
	}

	//����
	@Override
	public List<Material> getAllInstor() {
		// TODO �Զ����ɵķ������
		String hql="select m from Material as m,Instorage as i where m.mId=i.material.mId";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		return query.list();
	}

	@Override
	public List<Material> getAllOut() {
		// TODO �Զ����ɵķ������
		String hql="select m from Material as m,Outstorage as o where m.mId=o.material.mId";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		return query.list();
	}
	@Override
	public void deleteByName(Material materials) {
		// TODO �Զ����ɵķ������
		//ɾ���ӱ�
		String hqlString="delete from Instorage as i where i.material.id=?";
		Query queryString=getSessionFactory().getCurrentSession().createQuery(hqlString);
		queryString.setParameter(0, materials.getmId());
		queryString.executeUpdate();
		//ɾ������
		String hql="delete from Material m where m.mId=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, materials.getmId());
		query.executeUpdate();

	}

	@Override
	public void deleteById(Material material) {
		// TODO �Զ����ɵķ������
		String hqlString="delete from Outstorage as o where o.material.id=?";
		Query queryString=getSessionFactory().getCurrentSession().createQuery(hqlString);
		queryString.setParameter(0, material.getmId());
		queryString.executeUpdate();
		//ɾ������
		String hql="delete from Material m where m.mId=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, material.getmId());
		query.executeUpdate();
	}

	@Override
	public void updateById(Material material,Instorage instorage,Depot depot) {
		// TODO �Զ����ɵķ������
		//��������
		String updateinstor="update Instorage as i set intime=?,inaccount=?,inperson=?,allmoney=?where i.innum=?";
		Query queryString=getSessionFactory().getCurrentSession().createQuery(updateinstor);
		queryString.setParameter(0, instorage.getIntime());
		queryString.setParameter(1, instorage.getInaccount());
		queryString.setParameter(2, instorage.getInperson());
		queryString.setParameter(3, instorage.getAllmoney());
		queryString.setParameter(4, instorage.getInnum());
		queryString.executeUpdate();
		//�������ʱ�
		String updatemate="update Material as m set number=?,mtype=?,mbirth=?,muyear=?,maccount=?where m.mId=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(updatemate);
		query.setParameter(0, material.getNumber());
		query.setParameter(1, material.getMtype());
		query.setParameter(2, material.getMbirth());
		query.setParameter(3, material.getMuyear());
		query.setParameter(4, material.getMaccount());
		query.setParameter(5, material.getmId());
		query.executeUpdate();
		//���¿��
		String updatedepot="update Depot as d set dtime=?,daccount=?,dtype=?where d.dname=?";
		Query querysQuery=getSessionFactory().getCurrentSession().createQuery(updatedepot);
		querysQuery.setParameter(0, depot.getDtime());
		querysQuery.setParameter(1, depot.getDaccount());
		querysQuery.setParameter(2, depot.getDtype());
		querysQuery.setParameter(3, depot.getDname());
		querysQuery.executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Material> getById(int parseInt) {
		// TODO �Զ����ɵķ������
		String query="select m from Material as m where m.mId=?";
		Query queryString=getSessionFactory().getCurrentSession().createQuery(query);
		queryString.setParameter(0, parseInt);
		return queryString.list();
	}

	@Override
	public void updateOut(Material material, Outstorage outstorage, Depot depot) {
		// TODO �Զ����ɵķ������
		//���³����
				String updateoutstor="update Outstorage as o set outaccount=?,outtime=?,outperson=?,outreason=?where o.outnum=?";
				Query queryString=getSessionFactory().getCurrentSession().createQuery(updateoutstor);
				queryString.setParameter(0, outstorage.getOutaccount());
				queryString.setParameter(1, outstorage.getOuttime());
				queryString.setParameter(2, outstorage.getOutperson());
				queryString.setParameter(3, outstorage.getOutreason());
				queryString.setParameter(4, outstorage.getOutnum());
				queryString.executeUpdate();
	 //�������ʱ�
				String updatemate="update Material as m set maccount=?where m.mId=?";
				Query query=getSessionFactory().getCurrentSession().createQuery(updatemate);
				query.setParameter(0, material.getMaccount());
				query.setParameter(1, material.getmId());
				query.executeUpdate();
	//���¿��
				String updatedepot="update Depot as d set dtime=?,daccount=? where d.dname=?";
				Query querysQuery=getSessionFactory().getCurrentSession().createQuery(updatedepot);
				querysQuery.setParameter(0, depot.getDtime());
				querysQuery.setParameter(1, depot.getDaccount());
				querysQuery.setParameter(2, depot.getDname());
				querysQuery.executeUpdate();		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Material> getByNum(int i) {
		// TODO �Զ����ɵķ������
		String hql="select m from Material as m where m.number=?";
		Query query=getSessionFactory().getCurrentSession().createQuery(hql);
		query.setParameter(0, i);
		return query.list();
	}
}
