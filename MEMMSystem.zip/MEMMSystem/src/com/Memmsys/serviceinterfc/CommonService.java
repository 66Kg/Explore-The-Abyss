/**
 * 
 */
package com.Memmsys.serviceinterfc;

import java.util.List;

import com.Memmsys.database.MateAndinstor;

/**
 * @author wangyao
 *
 */
public interface CommonService extends BaseService<MateAndinstor> {

	List<Object> getAllTest();

	List<MateAndinstor> getAllByOut();

	List<Object> getBuyName(String string);

	void updateByid(String string, MateAndinstor mi);

	List<MateAndinstor> getMate(String hname);

}
