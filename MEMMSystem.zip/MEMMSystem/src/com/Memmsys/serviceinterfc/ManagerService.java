/**
 * 
 */
package com.Memmsys.serviceinterfc;

import com.Memmsys.database.Manager;

/**
 * @author wangyao
 *
 */
public interface ManagerService extends BaseService<Manager>{

	Manager login(Manager manager);

}
