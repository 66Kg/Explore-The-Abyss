package com.Memmsys.serviceinterfc;

import java.util.List;

import com.Memmsys.database.Depot;

public interface DepotService extends BaseService<Depot> {

	List<Depot> getByName(String mname);

	void updateDepot(Depot depot);

	List<Depot> getAllDepot();
}
