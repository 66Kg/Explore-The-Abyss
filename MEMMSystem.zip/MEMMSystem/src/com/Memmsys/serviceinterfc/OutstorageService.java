/**
 * 
 */
package com.Memmsys.serviceinterfc;

import java.util.List;

import com.Memmsys.DAOInterfc.OutstorageDAO;
import com.Memmsys.database.Outstorage;

/**
 * @author wangyao
 *
 */
public interface OutstorageService extends BaseService<Outstorage> {

	List<Object> getAllBynumber(String outnum);

	void deleteByNum(Outstorage outstorage);

	int getMid(int parseInt);

	int getByMnumber(int i);

}
