/**
 * 
 */
package com.Memmsys.serviceinterfc;

import java.util.Date;
import java.util.List;

import com.Memmsys.database.Depot;
import com.Memmsys.database.Instorage;
import com.Memmsys.database.Material;
import com.Memmsys.database.Outstorage;

/**
 * @author wangyao
 *
 */
public interface MateService extends BaseService<Material>{

	void updateByNum(String mnumber, Material materials);

	List<Material> getByName(String mname);

	List<Object> getOver();

	List<Object> getByTime(Date date);

	

	
	
	//����
	List<Material> getAllInstor();

	List<Material> getAllOut();
	
	void deleteByName(Material materials);

	void deleteById(Material material);

	void updateById(Material material, Instorage instorage, Depot depot);

	List<Material> getById(int parseInt);

	void updateOut(Material material, Outstorage outstorage, Depot depot);

	List<Material> getByNum(int i);

}
