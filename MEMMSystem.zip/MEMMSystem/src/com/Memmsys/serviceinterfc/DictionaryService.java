/**
 * 
 */
package com.Memmsys.serviceinterfc;

import java.util.List;

import com.Memmsys.database.Dictionary;

/**
 * @author wangyao
 *
 */
public interface DictionaryService extends BaseService<Dictionary> {

	List<Dictionary> getByName(String name);

	void updateByName(Dictionary dictionary);

}
