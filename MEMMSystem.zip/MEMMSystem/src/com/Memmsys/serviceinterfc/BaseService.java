package com.Memmsys.serviceinterfc;

import java.io.Serializable;
import java.util.List;

public interface BaseService<T> {
	
    public void add(T entity);

    public void delete(T entity);

    public void update(T entity);

    public T findById(Serializable id);

    public List<T> getAll();
   
}
