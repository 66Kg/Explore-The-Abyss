/**
 * 
 */
package com.Memmsys.serviceinterfc;

import com.Memmsys.database.Hospital;

/**
 * @author wangyao
 *
 */
public interface HospitalService extends  BaseService<Hospital>{
	void updateHos(Hospital hospital);

	void deleteByNum(Hospital hospital);
}
