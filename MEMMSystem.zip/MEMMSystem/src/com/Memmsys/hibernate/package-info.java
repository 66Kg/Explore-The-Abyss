/**
 * 
 */
/**
 * @author wangyao
 *
 */
package com.Memmsys.hibernate;