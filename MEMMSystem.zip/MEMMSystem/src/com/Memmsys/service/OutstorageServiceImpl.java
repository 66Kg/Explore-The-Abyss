/**
 * 
 */
package com.Memmsys.service;

import java.util.List;

import com.Memmsys.DAOInterfc.OutstorageDAO;
import com.Memmsys.database.Outstorage;
import com.Memmsys.serviceinterfc.OutstorageService;

/**
 * @author wangyao
 *
 */
public class OutstorageServiceImpl extends BaseServiceImpl<Outstorage>implements OutstorageService {
	private OutstorageDAO outstorageDAO;

	/**
	 * @param outstorageDAO Ҫ���õ� outstorageDAO
	 */
	public void setOutstorageDAO(OutstorageDAO outstorageDAO) {
		this.outstorageDAO = outstorageDAO;
		super.setBaseDAO(outstorageDAO);
	}

	@Override
	public List<Object> getAllBynumber(String outnum) {
		
		List<Object>list=outstorageDAO.getAllBynumber(outnum);
		return list;
	}

/*	@Override
	public void deleteByNum(Integer num) {
		// TODO �Զ����ɵķ������
		outstorageDAO.delete(num);
	}*/

	@Override
	public void deleteByNum(Outstorage outstorage) {
		// TODO �Զ����ɵķ������
		outstorageDAO.deleteBynum(outstorage);
	}

	@Override
	public int getMid(int parseInt) {
		// TODO �Զ����ɵķ������
		int i=outstorageDAO.getMid(parseInt);
		return i;
	}

	@Override
	public int getByMnumber(int i) {
		// TODO �Զ����ɵķ������
		int oaccount=outstorageDAO.getByMnumber(i);
		return oaccount;
	}

	
}
