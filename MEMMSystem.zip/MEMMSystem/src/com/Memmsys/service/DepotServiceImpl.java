/**
 * 
 */
package com.Memmsys.service;

import java.util.List;

import com.Memmsys.DAOInterfc.DepotDAO;
import com.Memmsys.database.Depot;
import com.Memmsys.serviceinterfc.DepotService;

/**
 * @author wangyao
 *
 */
public class DepotServiceImpl extends BaseServiceImpl<Depot>implements DepotService {
 private DepotDAO depotDAO;

/**
 * @param depotDAO Ҫ���õ� depotDAO
 */
public void setDepotDAO(DepotDAO depotDAO) {
	this.depotDAO = depotDAO;
	super.setBaseDAO(depotDAO);
}

@Override
public List<Depot> getByName(String mname) {
	// TODO �Զ����ɵķ������
	List<Depot>list=depotDAO.getByName(mname);
	return list;
}

@Override
public void updateDepot(Depot depot) {
	// TODO �Զ����ɵķ������
	depotDAO.updateDepot(depot);
}

@Override
public List<Depot> getAllDepot() {
	// TODO �Զ����ɵķ������
	List<Depot>list=depotDAO.getAllDepot();
	if (list==null) {
		return null;
	}
	return list;
}


}
