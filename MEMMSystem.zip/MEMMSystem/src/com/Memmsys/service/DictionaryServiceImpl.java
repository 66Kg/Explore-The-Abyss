/**
 * 
 */
package com.Memmsys.service;

import java.util.List;

import com.Memmsys.DAOInterfc.DictionaryDAO;
import com.Memmsys.database.Dictionary;
import com.Memmsys.serviceinterfc.DictionaryService;

/**
 * @author wangyao
 *
 */
public class DictionaryServiceImpl extends BaseServiceImpl<Dictionary>implements DictionaryService{
  private DictionaryDAO dictionaryDAO;

/**
 * @param dictionaryDAO Ҫ���õ� dictionaryDAO
 */
public void setDictionaryDAO(DictionaryDAO dictionaryDAO) {
	this.dictionaryDAO = dictionaryDAO;
	super.setBaseDAO(dictionaryDAO);
}

@Override
public List<Dictionary> getByName(String name) {
	// TODO �Զ����ɵķ������
	List<Dictionary>list=dictionaryDAO.getByName(name);
	return list;
}

@Override
public void updateByName(Dictionary dictionary) {
	// TODO �Զ����ɵķ������
	dictionaryDAO.updateByName(dictionary);
}
}
