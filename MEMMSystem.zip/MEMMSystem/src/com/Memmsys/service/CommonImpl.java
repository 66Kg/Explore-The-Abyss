/**
 * 
 */
package com.Memmsys.service;

import java.util.List;

import com.Memmsys.DAOInterfc.CommonDAO;
import com.Memmsys.database.MateAndinstor;
import com.Memmsys.serviceinterfc.CommonService;

/**
 * @author wangyao
 * 
 */
public class CommonImpl extends BaseServiceImpl<MateAndinstor> implements
		CommonService {
	private CommonDAO commonDAO;

	/**
	 * @param commonDAO
	 *            Ҫ���õ� commonDAO
	 */
	public void setCommonDAO(CommonDAO commonDAO) {
		this.commonDAO = commonDAO;
		super.setBaseDAO(commonDAO);
	}

	@Override
	public List<Object> getAllTest() {
		// TODO �Զ����ɵķ������
		List<Object>list=commonDAO.getAllTest();
		return list;
	}

	@Override
	public List<MateAndinstor> getAllByOut() {
		// TODO �Զ����ɵķ������
		List<MateAndinstor>list=commonDAO.getAllByOut();
		return list;
	}

	@Override
	public List<Object> getBuyName(String string) {
		// TODO �Զ����ɵķ������
	List<Object>list=commonDAO.getByName(string);
		return list;
	}

	@Override
	public void updateByid(String string, MateAndinstor mi) {
		commonDAO.updateByid(string, mi);
		// TODO �Զ����ɵķ������
		
	}

	@Override
	public List<MateAndinstor> getMate(String hname) {
		// TODO �Զ����ɵķ������
	List<MateAndinstor>list=commonDAO.getMates(hname);
		return list;
	}




}
