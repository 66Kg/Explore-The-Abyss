/**
 * 
 */
package com.Memmsys.service;

import java.util.List;
import java.util.Map;

import com.Memmsys.DAOInterfc.InstorageDAO;
import com.Memmsys.database.Instorage;
import com.Memmsys.serviceinterfc.InstorageService;

/**
 * @author wangyao
 *
 */
public class InstorageServiceImpl extends BaseServiceImpl<Instorage> implements InstorageService{

	private InstorageDAO instorageDAO;

	/**
	 * @param instorageDAO Ҫ���õ� instorageDAO
	 */
	public void setInstorageDAO(InstorageDAO instorageDAO) {
		this.instorageDAO = instorageDAO;
		super.setBaseDAO(instorageDAO);
	}

	public List<Object>getAllBynumber(String innum){
		List<Object>list=instorageDAO.getAllBynumber(innum);
		return list;
		
	}

	@Override
	public List<Object> getAllInstor() {
		// TODO �Զ����ɵķ������
		List<Object>listall=instorageDAO.getAllInstor();
		return listall;
	}

	@Override
	public void updateByNum(Instorage instorage) {
		// TODO �Զ����ɵķ������
		instorageDAO.updateByNum(instorage);
	}

	@Override
	public void deleteByNum(Instorage instorage) {
		// TODO �Զ����ɵķ������
		instorageDAO.deleteByName(instorage);
	}

	@Override
	public int getMid(int parseInt) {
		// TODO �Զ����ɵķ������
		int id=instorageDAO.getMid(parseInt);
		return id;
	}

	@Override
	public List<Instorage> getByNum(int parseInt) {
		// TODO �Զ����ɵķ������
		List<Instorage>instorages=instorageDAO.getByNum(parseInt);
		return instorages;
	}
	
}
