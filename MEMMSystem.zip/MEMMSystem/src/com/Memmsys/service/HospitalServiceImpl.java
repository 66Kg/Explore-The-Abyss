/**
 * 
 */
package com.Memmsys.service;

import org.springframework.stereotype.Service;

import com.Memmsys.DAOInterfc.HospitalDAO;
import com.Memmsys.database.Hospital;
import com.Memmsys.serviceinterfc.HospitalService;

/**
 * @author wangyao
 *
 */
@Service("HospitalService")
public class HospitalServiceImpl extends BaseServiceImpl<Hospital> implements HospitalService{
	private HospitalDAO hospitalDAO;

	/**
	 * @param hospitalDAO Ҫ���õ� hospitalDAO
	 */
	public void setHospitalDAO(HospitalDAO hospitalDAO) {
		this.hospitalDAO = hospitalDAO;
		super.setBaseDAO(hospitalDAO);
	}
	@Override
	public void updateHos(Hospital hospital) {
		// TODO �Զ����ɵķ������
		hospitalDAO.updateByid(hospital);
	}
	@Override
	public void deleteByNum(Hospital hospital) {
		// TODO �Զ����ɵķ������
		hospitalDAO.deleteByNum(hospital);
	}

}
