/**
 * 
 */
package com.Memmsys.database;

import java.util.Date;

/**
 * @author wangyao
 *
 */
public class Outstorage {
	private  int outId;
	private Date outtime;
	private int outnum;
	private int outaccount;
	private String outperson;
	private String outreason;
	
	private Material material;
	/**
	 * @return outId
	 */
	public int getOutId() {
		return outId;
	}
	/**
	 * @param outId Ҫ���õ� outId
	 */
	public void setOutId(int outId) {
		this.outId = outId;
	}
	/**
	 * @return outtime
	 */
	public Date getOuttime() {
		return outtime;
	}
	/**
	 * @param outtime Ҫ���õ� outtime
	 */
	public void setOuttime(Date outtime) {
		this.outtime = outtime;
	}
	/**
	 * @return outnum
	 */
	public int getOutnum() {
		return outnum;
	}
	/**
	 * @param outnum Ҫ���õ� outnum
	 */
	public void setOutnum(int outnum) {
		this.outnum = outnum;
	}
	/**
	 * @return outaccount
	 */
	public int getOutaccount() {
		return outaccount;
	}
	/**
	 * @param outaccount Ҫ���õ� outaccount
	 */
	public void setOutaccount(int outaccount) {
		this.outaccount = outaccount;
	}

	/**
	 * @return outperson
	 */
	public String getOutperson() {
		return outperson;
	}
	/**
	 * @param outperson Ҫ���õ� outperson
	 */
	public void setOutperson(String outperson) {
		this.outperson = outperson;
	}
	/**
	 * @return outreason
	 */
	public String getOutreason() {
		return outreason;
	}
	/**
	 * @param outreason Ҫ���õ� outreason
	 */
	public void setOutreason(String outreason) {
		this.outreason = outreason;
	}
	/**
	 * @return material
	 */
	public Material getMaterial() {
		return material;
	}
	/**
	 * @param material Ҫ���õ� material
	 */
	public void setMaterial(Material material) {
		this.material = material;
	}

}
