/**
 * 
 */
package com.Memmsys.database;

import java.util.Date;

/**
 * @author wangyao ����ʵ����
 * 
 */
public class Instorage {
	private int inId;
	private int innum;
	private Date intime;
	private int inaccount;
	private String inperson;
	private long allmoney;
	
	private Material material;

	/**
	 * @return inId
	 */
	public int getInId() {
		return inId;
	}

	/**
	 * @param inId
	 *            Ҫ���õ� inId
	 */
	public void setInId(int inId) {
		this.inId = inId;
	}

	/**
	 * @return intime
	 */
	public Date getIntime() {
		return intime;
	}

	/**
	 * @param intime
	 *            Ҫ���õ� intime
	 */
	public void setIntime(Date intime) {
		this.intime = intime;
	}

	/**
	 * @return innum
	 */
	public int getInnum() {
		return innum;
	}

	/**
	 * @param innum
	 *            Ҫ���õ� innum
	 */
	public void setInnum(int innum) {
		this.innum = innum;
	}

	/**
	 * @return inaccount
	 */
	public int getInaccount() {
		return inaccount;
	}

	/**
	 * @param inaccount
	 *            Ҫ���õ� inaccount
	 */
	public void setInaccount(int inaccount) {
		this.inaccount = inaccount;
	}

	/**
	 * @return inperson
	 */
	public String getInperson() {
		return inperson;
	}

	/**
	 * @param inperson
	 *            Ҫ���õ� inperson
	 */
	public void setInperson(String inperson) {
		this.inperson = inperson;
	}
	/**
	 * @return allmoney
	 */
	public long getAllmoney() {
		return allmoney;
	}

	/**
	 * @param allmoney Ҫ���õ� allmoney
	 */
	public void setAllmoney(long allmoney) {
		this.allmoney = allmoney;
	}

	/**
	 * @return material
	 */
	public Material getMaterial() {
		return material;
	}

	/**
	 * @param material Ҫ���õ� material
	 */
	public void setMaterial(Material material) {
		this.material = material;
	}
}
