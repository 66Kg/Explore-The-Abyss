/**
 * 
 */
package com.Memmsys.database;

/**
 * @author wangyao ��Ҫ���յ�User����
 * 
 */
public class Manager {
	private int userid;
	private String name;
	private String password;

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            Ҫ���õ� name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            Ҫ���õ� password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return userid
	 */
	public int getUserid() {
		return userid;
	}

	/**
	 * @param userid
	 *            Ҫ���õ� userid
	 */
	public void setUserid(int userid) {
		this.userid = userid;
	}

}
