/**
 * 
 */
package com.Memmsys.database;

/**
 * @author wangyao
 *
 */
public class Dictionary {

	private int eid;
	private String ename;
	private String eename;
	private String eground;
	private String euse;
	private String espec;
	private String epeople;
	private String ebadside;
	
	private Depot depot;
	
	/**
	 * @return eid
	 */
	public int getEid() {
		return eid;
	}
	/**
	 * @param eid Ҫ���õ� eid
	 */
	public void setEid(int eid) {
		this.eid = eid;
	}
	/**
	 * @return ename
	 */
	public String getEname() {
		return ename;
	}
	/**
	 * @param ename Ҫ���õ� ename
	 */
	public void setEname(String ename) {
		this.ename = ename;
	}
	/**
	 * @return eename
	 */
	public String getEename() {
		return eename;
	}
	/**
	 * @param eename Ҫ���õ� eename
	 */
	public void setEename(String eename) {
		this.eename = eename;
	}
	/**
	 * @return eground
	 */
	public String getEground() {
		return eground;
	}
	/**
	 * @param eground Ҫ���õ� eground
	 */
	public void setEground(String eground) {
		this.eground = eground;
	}
	/**
	 * @return euse
	 */
	public String getEuse() {
		return euse;
	}
	/**
	 * @param euse Ҫ���õ� euse
	 */
	public void setEuse(String euse) {
		this.euse = euse;
	}
	/**
	 * @return espec
	 */
	public String getEspec() {
		return espec;
	}
	/**
	 * @param espec Ҫ���õ� espec
	 */
	public void setEspec(String espec) {
		this.espec = espec;
	}
	/**
	 * @return epeople
	 */
	public String getEpeople() {
		return epeople;
	}
	/**
	 * @param epeople Ҫ���õ� epeople
	 */
	public void setEpeople(String epeople) {
		this.epeople = epeople;
	}
	/**
	 * @return ebadside
	 */
	public String getEbadside() {
		return ebadside;
	}
	/**
	 * @param ebadside Ҫ���õ� ebadside
	 */
	public void setEbadside(String ebadside) {
		this.ebadside = ebadside;
	}
	/**
	 * @return depot
	 */
	public Depot getDepot() {
		return depot;
	}
	/**
	 * @param depot Ҫ���õ� depot
	 */
	public void setDepot(Depot depot) {
		this.depot = depot;
	}
}
