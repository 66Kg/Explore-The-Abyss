 /**
 * 
 */
package com.Memmsys.database;

/**
 * @author wangyao/4.25
 * ҽԺʵ����
 *
 */
public class Hospital {
	private int hId;
	private int hnumber;
	private String hname;
	private String hphoneString;
	private String haddress;
	private String howner;
	
	/**
	 * @return hId
	 */
	public int gethId() {
		return hId;
	}
	/**
	 * @param hId Ҫ���õ� hId
	 */
	public void sethId(int hId) {
		this.hId = hId;
	}
	/**
	 * @return hname
	 */
	public String getHname() {
		return hname;
	}
	/**
	 * @param hname Ҫ���õ� hname
	 */
	public void setHname(String hname) {
		this.hname = hname;
	}
	/**
	 * @return hphoneString
	 */
	public String getHphoneString() {
		return hphoneString;
	}
	/**
	 * @param hphoneString Ҫ���õ� hphoneString
	 */
	public void setHphoneString(String hphoneString) {
		this.hphoneString = hphoneString;
	}
	/**
	 * @return haddress
	 */
	public String getHaddress() {
		return haddress;
	}
	/**
	 * @param haddress Ҫ���õ� haddress
	 */
	public void setHaddress(String haddress) {
		this.haddress = haddress;
	}
	/**
	 * @return howner
	 */
	public String getHowner() {
		return howner;
	}
	/**
	 * @param howner Ҫ���õ� howner
	 */
	public void setHowner(String howner) {
		this.howner = howner;
	}
	/**
	 * @return hnumber
	 */
	public int getHnumber() {
		return hnumber;
	}
	/**
	 * @param hnumber Ҫ���õ� hnumber
	 */
	public void setHnumber(int hnumber) {
		this.hnumber = hnumber;
	}
}
