/**
 * 
 */
package com.Memmsys.database;

import java.util.Date;
import java.util.Set;

/**
 * @author wangyao
 *
 */
public class Material {
private int mId;
private int number;
private String mname;
private String mtype;
private Date mbirth;
private Date muyear;
private int maccount;

private Set<Instorage>instorages;
private Set<Outstorage>outstorages;

private Depot depot;

/**
 * @return mtype
 */
public String getMtype() {
	return mtype;
}
/**
 * @param mtype Ҫ���õ� mtype
 */
public void setMtype(String mtype) {
	this.mtype = mtype;
}
/**
 * @return mbirth
 */
public Date getMbirth() {
	return mbirth;
}
/**
 * @param mbirth Ҫ���õ� mbirth
 */
public void setMbirth(Date mbirth) {
	this.mbirth = mbirth;
}

/**
 * @return mId
 */
public int getmId() {
	return mId;
}
/**
 * @param mId Ҫ���õ� mId
 */
public void setmId(int mId) {
	this.mId = mId;
}
/**
 * @return mname
 */
public String getMname() {
	return mname;
}
/**
 * @param mname Ҫ���õ� mname
 */
public void setMname(String mname) {
	this.mname = mname;
}
/**
 * @return muyear
 */
public Date getMuyear() {
	return muyear;
}
/**
 * @param muyear Ҫ���õ� muyear
 */
public void setMuyear(Date muyear) {
	this.muyear = muyear;
}
/**
 * @return number
 */
public int getNumber() {
	return number;
}
/**
 * @param number Ҫ���õ� number
 */
public void setNumber(int number) {
	this.number = number;
}
/**
 * @return instorages
 */
public Set<Instorage> getInstorages() {
	return instorages;
}
/**
 * @param instorages Ҫ���õ� instorages
 */
public void setInstorages(Set<Instorage> instorages) {
	this.instorages = instorages;
}
/**
 * @return outstorages
 */
public Set<Outstorage> getOutstorages() {
	return outstorages;
}
/**
 * @param outstorages Ҫ���õ� outstorages
 */
public void setOutstorages(Set<Outstorage> outstorages) {
	this.outstorages = outstorages;
}
/**
 * @return maccount
 */
public int getMaccount() {
	return maccount;
}
/**
 * @param maccount Ҫ���õ� maccount
 */
public void setMaccount(int maccount) {
	this.maccount = maccount;
}
/**
 * @return depot
 */
public Depot getDepot() {
	return depot;
}
/**
 * @param depot Ҫ���õ� depot
 */
public void setDepot(Depot depot) {
	this.depot = depot;
}
}
