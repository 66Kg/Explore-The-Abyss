/**
 * 
 */
package com.Memmsys.database;

import java.util.Date;
import java.util.Set;

/**
 * @author wangyao
 *
 */
public class Depot {

	private int dId;
	private String dname;
	private Date dtime;
	private int daccount;
	private String dtype;
	private Set<Material>materials;
	private Set<Dictionary>dictionaries;
	/**
	 * @return dId
	 */
	public int getdId() {
		return dId;
	}
	/**
	 * @param dId Ҫ���õ� dId
	 */
	public void setdId(int dId) {
		this.dId = dId;
	}
	/**
	 * @return dname
	 */
	public String getDname() {
		return dname;
	}
	/**
	 * @param dname Ҫ���õ� dname
	 */
	public void setDname(String dname) {
		this.dname = dname;
	}
	/**
	 * @return dtime
	 */
	public Date getDtime() {
		return dtime;
	}
	/**
	 * @param dtime Ҫ���õ� dtime
	 */
	public void setDtime(Date dtime) {
		this.dtime = dtime;
	}
	/**
	 * @return daccount
	 */
	public int getDaccount() {
		return daccount;
	}
	/**
	 * @param daccount Ҫ���õ� daccount
	 */
	public void setDaccount(int daccount) {
		this.daccount = daccount;
	}
	/**
	 * @return dtype
	 */
	public String getDtype() {
		return dtype;
	}
	/**
	 * @param dtype Ҫ���õ� dtype
	 */
	public void setDtype(String dtype) {
		this.dtype = dtype;
	}
	/**
	 * @return materials
	 */
	public Set<Material> getMaterials() {
		return materials;
	}
	/**
	 * @param materials Ҫ���õ� materials
	 */
	public void setMaterials(Set<Material> materials) {
		this.materials = materials;
	}
	/**
	 * @return dictionaries
	 */
	public Set<Dictionary> getDictionaries() {
		return dictionaries;
	}
	/**
	 * @param dictionaries Ҫ���õ� dictionaries
	 */
	public void setDictionaries(Set<Dictionary> dictionaries) {
		this.dictionaries = dictionaries;
	}
	
	
}
