/**
 * 
 */
package com.Memmsys.database;

/**
 * @author wangyao
 *
 */
public class MateAndinstor {
	private int miId;
	private String miname;
	private String hname;
	private long moneyl;
	private long allmoney;
	private int maccount;
	 private Instorage instorage;
	 private Outstorage outstorages;
	 private Material materials;
	/**
	 * @return miId
	 */
	public int getMiId() {
		return miId;
	}
	/**
	 * @param miId Ҫ���õ� miId
	 */
	public void setMiId(int miId) {
		this.miId = miId;
	}

	/**
	 * @return moneyl
	 */
	public long getMoneyl() {
		return moneyl;
	}
	/**
	 * @param moneyl Ҫ���õ� moneyl
	 */
	public void setMoneyl(long moneyl) {
		this.moneyl = moneyl;
	}
	/**
	 * @return allmoney
	 */
	public long getAllmoney() {
		return allmoney;
	}
	/**
	 * @param allmoney Ҫ���õ� allmoney
	 */
	public void setAllmoney(long allmoney) {
		this.allmoney = allmoney;
	}
	/**
	 * @return miname
	 */
	public String getMiname() {
		return miname;
	}
	/**
	 * @param miname Ҫ���õ� miname
	 */
	public void setMiname(String miname) {
		this.miname = miname;
	}
	/**
	 * @return instorage
	 */
	public Instorage getInstorage() {
		return instorage;
	}
	/**
	 * @param instorage Ҫ���õ� instorage
	 */
	public void setInstorage(Instorage instorage) {
		this.instorage = instorage;
	}
	/**
	 * @return outstorages
	 */
	public Outstorage getOutstorages() {
		return outstorages;
	}
	/**
	 * @param outstorages Ҫ���õ� outstorages
	 */
	public void setOutstorages(Outstorage outstorages) {
		this.outstorages = outstorages;
	}
	/**
	 * @return maccount
	 */
	public int getMaccount() {
		return maccount;
	}
	/**
	 * @param maccount Ҫ���õ� maccount
	 */
	public void setMaccount(int maccount) {
		this.maccount = maccount;
	}
	/**
	 * @return hname
	 */
	public String getHname() {
		return hname;
	}
	/**
	 * @param hname Ҫ���õ� hname
	 */
	public void setHname(String hname) {
		this.hname = hname;
	}
	/**
	 * @return materials
	 */
	public Material getMaterials() {
		return materials;
	}
	/**
	 * @param materials Ҫ���õ� materials
	 */
	public void setMaterials(Material materials) {
		this.materials = materials;
	}

}
