/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.util.List;

import com.Memmsys.database.Outstorage;

/**
 * @author wangyao
 *
 */
public interface OutstorageDAO extends BaseDAO<Outstorage>{


	List<Object> getAllBynumber(String outnum);

	void delete(Integer num);

	void deleteBynum(Outstorage outstorage);

	int getMid(int parseInt);

	int getByMnumber(int i);

}
