/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.util.List;
import java.util.Map;

import com.Memmsys.database.Instorage;

/**
 * @author wangyao
 *
 */
public interface InstorageDAO extends BaseDAO<Instorage>{
     List<Object>getAllBynumber(String innum);
	 List<Object> getAllInstor();
	void updateByNum(Instorage instorage);
	void deleteByName(Instorage instorage);
	int getMid(int parseInt);
	List<Instorage> getByNum(int parseInt);
}
