/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.util.List;

import com.Memmsys.database.MateAndinstor;
import com.Memmsys.serviceinterfc.CommonService;

/**
 * @author wangyao
 *
 */
public interface CommonDAO extends BaseDAO<MateAndinstor> {

	List<Object> getAllTest();

	List<MateAndinstor> getAllByOut();

	List<Object> getByName(String string);

	void updateByid(String string, MateAndinstor mi);

	List<MateAndinstor> getMates(String hname);
}
