/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.io.Serializable;
import java.util.List;

/**
 * @author wangyao
 *
 */
public interface BaseDAO <T>{

	public void add(T t);
	public void delete(T t);
	public void update(T t);
	public T get(Serializable id);
	public List<T>getAll();
	public List<T>getListByHQL(String hqString,Object... value);
	
}
