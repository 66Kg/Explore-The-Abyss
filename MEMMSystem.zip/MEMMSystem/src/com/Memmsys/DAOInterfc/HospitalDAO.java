/**
 * 
 */
package com.Memmsys.DAOInterfc;

import com.Memmsys.database.Hospital;

/**
 * @author wangyao
 *
 */
public interface HospitalDAO extends BaseDAO<Hospital>{

	void updateByid(Hospital hospital);

	void deleteByNum(Hospital hospital);
}
