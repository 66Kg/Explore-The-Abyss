/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.util.List;

import com.Memmsys.database.Dictionary;

/**
 * @author wangyao
 *
 */
public interface DictionaryDAO extends BaseDAO<Dictionary>{

	List<Dictionary> getByName(String name);

	void updateByName(Dictionary dictionary);

}
