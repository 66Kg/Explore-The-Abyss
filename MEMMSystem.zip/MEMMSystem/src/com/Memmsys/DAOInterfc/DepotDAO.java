/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.util.List;

import com.Memmsys.database.Depot;

/**
 * @author wangyao
 *
 */
public interface DepotDAO extends BaseDAO<Depot> {

	List<Depot> getByName(String mname);

	void updateDepot(Depot depot);

	List<Depot> getAllDepot();

}
