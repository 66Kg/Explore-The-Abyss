/**
 * 
 */
package com.Memmsys.DAOInterfc;

import java.util.Date;
import java.util.List;

import com.Memmsys.database.Depot;
import com.Memmsys.database.Instorage;
import com.Memmsys.database.Material;
import com.Memmsys.database.Outstorage;

/**
 * @author wangyao
 *
 */
public interface MateDAO extends BaseDAO<Material>{

	void updateByNum(String mnumber, Material materials);

	List<Material> getByName(String mname);

	List<Object> getOver();

	List<Object> getOverInfo(Date date);

	void deleteByName(Material materials);
	
	
//����
	List<Material> getAllInstor();

	List<Material> getAllOut();

	void deleteById(Material material);

	void updateById(Material material, Instorage instorage, Depot depot);

	List<Material> getById(int parseInt);

	void updateOut(Material material, Outstorage outstorage, Depot depot);

	List<Material> getByNum(int i);

}
