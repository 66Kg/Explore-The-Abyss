/**
 * 
 */
package com.Memmsys.DAOInterfc;

import com.Memmsys.database.Manager;

/**
 * @author wangyao
 *
 */
public interface ManagerDAO extends BaseDAO<Manager>{

	Manager findByNP(Manager manager);


}
