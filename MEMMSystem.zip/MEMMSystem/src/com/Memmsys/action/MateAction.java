/**
 * 
 */
package com.Memmsys.action;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.Memmsys.database.Depot;
import com.Memmsys.database.Material;
import com.Memmsys.database.Outstorage;
import com.Memmsys.serviceinterfc.DepotService;
import com.Memmsys.serviceinterfc.MateService;
import com.Memmsys.serviceinterfc.OutstorageService;
import com.opensymphony.xwork2.ActionSupport;
/**
 * @author wangyao
 *
 */
@SuppressWarnings("serial")
public class MateAction extends ActionSupport{
	Material material=new Material();
	Depot depot=new Depot();
	
	private String mid;
	private String number;
	private String mname;
	private String mtype;
	private String mbirth;
	private String muyear;
	private String maccount;
	
	private MateService mateService;
	private DepotService depotService;
	private OutstorageService outstorageService;
	
	private List<Material>list;
	private List<Depot>dlist;
	private List<Map<String, Object>> dataList;
	
	//���ȫ���������ʣ����ʱ�����ʣ�
	public String getAllOver(){
		list=mateService.getAllInstor();
		dataList = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < list.size(); i++) {
			Material material = list.get(i);
			Date now = new Date();
			if (material.getMuyear().compareTo(now) < 0) {
				List<Outstorage>lOutstorages=outstorageService.getAll();
                   if(lOutstorages.size()==0){
                	  HashMap<String, Object> map = new HashMap<String, Object>();
       				map.put("mid", material.getmId());
       				map.put("mname", material.getMname());
       				map.put("number", material.getNumber());
       				map.put("mtype", material.getMtype());
       				map.put("maccount", material.getMaccount());
       				map.put("mbirth", material.getMbirth());
       				map.put("muyear", material.getMuyear());
       				dataList.add(map);
                   }
				else {
					//��¼�ù������������Ѿ������˶���
					int oaccount=outstorageService.getByMnumber(material.getNumber());
					System.out.println(oaccount);
					HashMap<String, Object> map = new HashMap<String, Object>();
					map.put("mid", material.getmId());
					map.put("mname", material.getMname());
					map.put("number", material.getNumber());
					map.put("mtype", material.getMtype());
					map.put("maccount", material.getMaccount()-oaccount);
					map.put("mbirth", material.getMbirth());
					map.put("muyear", material.getMuyear());
					dataList.add(map);
				}
			}
		}
		return SUCCESS;	
	}
	//��ȡ�ֿ�ȫ����Ϣ
	public String getAll() {
		dlist=depotService.getAll();
		if (dlist!=null) {
			return SUCCESS;
		}
		return "nodata";
	}
	//ɾ�����������Ϣ
	public String delete(){
		material.setmId(Integer.parseInt(mid));
		mateService.deleteByName(material);
		return SUCCESS;	
	}
	//ɾ�����ʳ�����Ϣ
	public String del(){
		material.setmId(Integer.parseInt(mid));
		mateService.deleteById(material);
		return SUCCESS;
	}
	//ɾ��������Ϣ
	public String delover(){
		//ɾ���������ʺ��޸�ͳ�Ʊ�
		try {
			String ss=new String(mname.getBytes("ISO-8859-1"),"utf-8");
			List<Depot>depots=depotService.getByName(ss);
			 int newaccount=depots.get(0).getDaccount()-Integer.parseInt(maccount);
			 System.out.println("new������Ϊ"+newaccount);
			  depot.setDaccount(newaccount);
			  depot.setDname(ss);
			  depotService.updateDepot(depot);
		} catch (UnsupportedEncodingException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}    
		material.setmId(Integer.parseInt(mid));
		mateService.deleteByName(material);
		return SUCCESS;
	}
	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number Ҫ���õ� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return mname
	 */
	public String getMname() {
		return mname;
	}

	/**
	 * @param mname Ҫ���õ� mname
	 */
	public void setMname(String mname) {
		this.mname = mname;
	}

	/**
	 * @return mtype
	 */
	public String getMtype() {
		return mtype;
	}

	/**
	 * @param mtype Ҫ���õ� mtype
	 */
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}

	/**
	 * @return mbirth
	 */
	public String getMbirth() {
		return mbirth;
	}

	/**
	 * @param mbirth Ҫ���õ� mbirth
	 */
	public void setMbirth(String mbirth) {
		this.mbirth = mbirth;
	}

	/**
	 * @return muyear
	 */
	public String getMuyear() {
		return muyear;
	}

	/**
	 * @param muyear Ҫ���õ� muyear
	 */
	public void setMuyear(String muyear) {
		this.muyear = muyear;
	}

	/**
	 * @return maccount
	 */
	public String getMaccount() {
		return maccount;
	}

	/**
	 * @param maccount Ҫ���õ� maccount
	 */
	public void setMaccount(String maccount) {
		this.maccount = maccount;
	}

	/**
	 * @param mateService Ҫ���õ� mateService
	 */
	public void setMateService(MateService mateService) {
		this.mateService = mateService;
	}

	/**
	 * @return list
	 */
	public List<Material> getList() {
		return list;
	}

	/**
	 * @return dataList
	 */
	public List<Map<String, Object>> getDataList() {
		return dataList;
	}
	/**
	 * @param depotService Ҫ���õ� depotService
	 */
	public void setDepotService(DepotService depotService) {
		this.depotService = depotService;
	}
	/**
	 * @return dlist
	 */
	public List<Depot> getDlist() {
		return dlist;
	}
	/**
	 * @return mid
	 */
	public String getMid() {
		return mid;
	}
	/**
	 * @param mid Ҫ���õ� mid
	 */
	public void setMid(String mid) {
		this.mid = mid;
	}
	/**
	 * @param outstorageService Ҫ���õ� outstorageService
	 */
	public void setOutstorageService(OutstorageService outstorageService) {
		this.outstorageService = outstorageService;
	}

	
}
