/**
 * 
 */
package com.Memmsys.action;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.Memmsys.database.Depot;
import com.Memmsys.database.Instorage;
import com.Memmsys.database.Material;
import com.Memmsys.database.Outstorage;
import com.Memmsys.serviceinterfc.DepotService;
import com.Memmsys.serviceinterfc.InstorageService;
import com.Memmsys.serviceinterfc.MateService;
import com.Memmsys.serviceinterfc.OutstorageService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author wangyao
 * 
 */
@SuppressWarnings("serial")
public class OutstorAction extends ActionSupport {
	Outstorage outstorage = new Outstorage();
	Material material = new Material();
	Instorage instorage = new Instorage();
	Depot depot = new Depot();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

	private String mid;
	private String number;
	private String mname;
	private String mtype;
	private String mbirth;
	private String muyear;

	private String outtime;
	private String outnum;
	private String outaccount;
	private String outperson;
	private String outreason;

	private MateService mateService;
	private OutstorageService outstorageService;
	private DepotService depotService;
	private InstorageService instorageService;

	private List<Material> list;
	private List<Outstorage> outlist;
	private List<Map<String, Object>> dataList;

	// ���ʳ���
	public String add() {
		List<Material> ms = mateService.getByNum(Integer.parseInt(number));
		if (ms == null) {
			return "nodata";
		}
		List<Depot> lDepots = depotService.getByName(mname);
		System.out.println(lDepots.size());
		// ����Ҫ��:1��Ҫ���ڴ����� 2������������Ϊ0 3����������������������4������ָ�����������ȳ���������
		if (lDepots.size() != 0 && lDepots.get(0).getDaccount() > 0
				&& lDepots.get(0).getDaccount() >= Integer.parseInt(outaccount)
				&& ms.get(0).getMaccount() > Integer.parseInt(outaccount)) {
			material.setMname(mname);
			material.setMtype(ms.get(0).getMtype());
			material.setNumber(Integer.parseInt(number));
			material.setMbirth(ms.get(0).getMbirth());
			material.setMuyear(ms.get(0).getMuyear());
			outstorage.setOutaccount(Integer.parseInt(outaccount));
			outstorage.setOutnum(Integer.parseInt(outnum));
			outstorage.setOutperson(outperson);
			Date outdate;
			try {
				outdate = sdf.parse(outtime);
				outstorage.setOuttime(outdate);
			} catch (ParseException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			outstorage.setOutreason(outreason);
			outstorage.setMaterial(material);
			outstorageService.add(outstorage);

			int newAccount = lDepots.get(0).getDaccount()
					- Integer.parseInt(outaccount);
			depot.setDname(mname);
			depot.setDaccount(newAccount);
			depotService.updateDepot(depot);
			return SUCCESS;
		} else {
			return "nodata";
		}
	}

	// ��ѯ���ʳ�����Ϣ
	public String getAll() {
		outlist = outstorageService.getAll();
		list = mateService.getAllOut();
		dataList = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < outlist.size(); i++) {
			Outstorage outstorage = outlist.get(i);
			Material material = list.get(i);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("mid", material.getmId());
			map.put("mname", material.getMname());
			map.put("number", material.getNumber());
			map.put("mtype", material.getMtype());
			map.put("mbirth", material.getMbirth());
			map.put("muyear", material.getMuyear());
			map.put("outnum", outstorage.getOutnum());
			map.put("outaccount", outstorage.getOutaccount());
			map.put("outperson", outstorage.getOutperson());
			map.put("outreason", outstorage.getOutreason());
			map.put("outtime", outstorage.getOuttime());
			dataList.add(map);
		}
		return SUCCESS;
	}

	// �ҵ�Ŀ����Ϣ
	public String topage() throws UnsupportedEncodingException {
		String name = new String(mname.getBytes("ISO-8859-1"), "utf-8");
		ActionContext.getContext().getSession().put("mname", name);
		ActionContext.getContext().getSession().put("outaccount", outaccount);
		ActionContext.getContext().getSession().put("outnum", outnum);
		ActionContext.getContext().getSession().put("number", number);
		return SUCCESS;
	}

	// �޸�������Ϣ
	public String update() {
		List<Instorage> instorages = instorageService.getByNum(Integer.parseInt(ActionContext
				.getContext().getSession().get("number").toString()));
		List<Depot> lDepots = depotService.getByName(ActionContext
				.getContext().getSession().get("mname").toString());
		//1������ͳ�Ʊ��д���  2��ͳ�Ʊ���������0����ͳ�Ʊ������ȸó���������  3�����ʱ����������
		if (lDepots.size() != 0 
				&& lDepots.get(0).getDaccount() > 0
				&& lDepots.get(0).getDaccount() >= Integer.parseInt(outaccount)
				&& instorages.get(0).getInaccount() > Integer.parseInt(outaccount)) {
			int id = outstorageService.getMid(Integer.parseInt(ActionContext
					.getContext().getSession().get("outnum").toString()));
			material.setmId(id);
			material.setMaccount(Integer.parseInt(outaccount));
			// ���³�����Ϣ��
			outstorage.setOutnum(Integer.parseInt(ActionContext.getContext()
					.getSession().get("outnum").toString()));
			outstorage.setOutaccount(Integer.parseInt(outaccount));
			outstorage.setOutperson(outperson);
			outstorage.setOutreason(outreason);
			Date dt;
			try {
				dt = sdf.parse(outtime);
				outstorage.setOuttime(dt);
			} catch (ParseException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			// ����ͳ�Ʊ�
			List<Depot> depots = depotService.getByName(ActionContext
					.getContext().getSession().get("mname").toString());
			if (Integer.parseInt((String) ActionContext.getContext()
					.getSession().get("outaccount")) < Integer
					.parseInt(outaccount)) {
				int clnum = Integer.parseInt((String) ActionContext
						.getContext().getSession().get("outaccount"))
						- Integer.parseInt(outaccount);
				int newaccount = depots.get(0).getDaccount() + clnum;
				depot.setDaccount(newaccount);
			} else {
				int clnum = Integer.parseInt(outaccount)
						- Integer.parseInt((String) ActionContext.getContext()
								.getSession().get("outaccount"));
				int newaccount = depots.get(0).getDaccount() - clnum;
				depot.setDaccount(newaccount);
			}
			depot.setDname(ActionContext.getContext().getSession().get("mname")
					.toString());
			Date date = new Date();
			depot.setDtime(date);
			mateService.updateOut(material, outstorage, depot);
			return SUCCESS;
		}
		return "nodata";

	}

	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number
	 *            Ҫ���õ� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return mname
	 */
	public String getMname() {
		return mname;
	}

	/**
	 * @param mname
	 *            Ҫ���õ� mname
	 */
	public void setMname(String mname) {
		this.mname = mname;
	}

	/**
	 * @return mtype
	 */
	public String getMtype() {
		return mtype;
	}

	/**
	 * @param mtype
	 *            Ҫ���õ� mtype
	 */
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}

	/**
	 * @return mbirth
	 */
	public String getMbirth() {
		return mbirth;
	}

	/**
	 * @param mbirth
	 *            Ҫ���õ� mbirth
	 */
	public void setMbirth(String mbirth) {
		this.mbirth = mbirth;
	}

	/**
	 * @return muyear
	 */
	public String getMuyear() {
		return muyear;
	}

	/**
	 * @param muyear
	 *            Ҫ���õ� muyear
	 */
	public void setMuyear(String muyear) {
		this.muyear = muyear;
	}

	/**
	 * @return outtime
	 */
	public String getOuttime() {
		return outtime;
	}

	/**
	 * @param outtime
	 *            Ҫ���õ� outtime
	 */
	public void setOuttime(String outtime) {
		this.outtime = outtime;
	}

	/**
	 * @return outnum
	 */
	public String getOutnum() {
		return outnum;
	}

	/**
	 * @param outnum
	 *            Ҫ���õ� outnum
	 */
	public void setOutnum(String outnum) {
		this.outnum = outnum;
	}

	/**
	 * @return outaccount
	 */
	public String getOutaccount() {
		return outaccount;
	}

	/**
	 * @param outaccount
	 *            Ҫ���õ� outaccount
	 */
	public void setOutaccount(String outaccount) {
		this.outaccount = outaccount;
	}

	/**
	 * @return outperson
	 */
	public String getOutperson() {
		return outperson;
	}

	/**
	 * @param outperson
	 *            Ҫ���õ� outperson
	 */
	public void setOutperson(String outperson) {
		this.outperson = outperson;
	}

	/**
	 * @return outreason
	 */
	public String getOutreason() {
		return outreason;
	}

	/**
	 * @param outreason
	 *            Ҫ���õ� outreason
	 */
	public void setOutreason(String outreason) {
		this.outreason = outreason;
	}

	/**
	 * @return list
	 */
	public List<Material> getList() {
		return list;
	}

	/**
	 * @return dataList
	 */
	public List<Map<String, Object>> getDataList() {
		return dataList;
	}

	/**
	 * @param mateService
	 *            Ҫ���õ� mateService
	 */
	public void setMateService(MateService mateService) {
		this.mateService = mateService;
	}

	/**
	 * @param outstorageService
	 *            Ҫ���õ� outstorageService
	 */
	public void setOutstorageService(OutstorageService outstorageService) {
		this.outstorageService = outstorageService;
	}

	/**
	 * @return outlist
	 */
	public List<Outstorage> getOutlist() {
		return outlist;
	}

	/**
	 * @param depotService
	 *            Ҫ���õ� depotService
	 */
	public void setDepotService(DepotService depotService) {
		this.depotService = depotService;
	}

	/**
	 * @return mid
	 */
	public String getMid() {
		return mid;
	}

	/**
	 * @param mid
	 *            Ҫ���õ� mid
	 */
	public void setMid(String mid) {
		this.mid = mid;
	}

	/**
	 * @param instorageService
	 *            Ҫ���õ� instorageService
	 */
	public void setInstorageService(InstorageService instorageService) {
		this.instorageService = instorageService;
	}
}
