/**
 * 
 */
package com.Memmsys.action;
import java.util.List;
import org.apache.struts2.ServletActionContext;
import com.Memmsys.database.Hospital;
import com.Memmsys.serviceinterfc.HospitalService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
/**
 * @author wangyao ҽԺ������Action�� ��Ϊ������org.apche.struts2���е�default
 *  proties�ļ�����ͨ����ͳ��webapplicationcontext��ķ�ʽ
 * 
 */
@SuppressWarnings("serial")
public class HosAction extends ActionSupport {
	Hospital hospital = new Hospital();
	private String hnumber;
	private String hname;
	private String hphoneString;
	private String haddress;
	private String howner;
	
	private List<Hospital> newlist;
	/**
	 * @return hnumber
	 */
	public String getHnumber() {
		return hnumber;
	}

	/**
	 * @param hnumber
	 *            Ҫ���õ� hnumber
	 */
	public void setHnumber(String hnumber) {
		this.hnumber = hnumber;
	}

	/**
	 * @return hname
	 */
	public String getHname() {
		return hname;
	}

	/**
	 * @param hname
	 *            Ҫ���õ� hname
	 */
	public void setHname(String hname) {
		this.hname = hname;
	}

	/**
	 * @return hphoneString
	 */
	public String getHphoneString() {
		return hphoneString;
	}

	/**
	 * @param hphoneString
	 *            Ҫ���õ� hphoneString
	 */
	public void setHphoneString(String hphoneString) {
		this.hphoneString = hphoneString;
	}

	/**
	 * @return haddress
	 */
	public String getHaddress() {
		return haddress;
	}

	/**
	 * @param haddress
	 *            Ҫ���õ� haddress
	 */
	public void setHaddress(String haddress) {
		this.haddress = haddress;
	}

	/**
	 * @return howner
	 */
	public String getHowner() {
		return howner;
	}

	/**
	 * @param howner
	 *            Ҫ���õ� howner
	 */
	public void setHowner(String howner) {
		this.howner = howner;
	}

	private HospitalService hospitalService;

	/**
	 * @param hospitalService
	 *            Ҫ���õ� hospitalService
	 */
	public void setHospitalService(HospitalService hospitalService) {
		this.hospitalService = hospitalService;
	}

	/* �������ʿ���Ϣ */
	public String add() {
		hospital.setHaddress(haddress);
		hospital.setHname(hname);
		hospital.setHnumber(Integer.parseInt(hnumber));
		hospital.setHowner(howner);
		hospital.setHphoneString(hphoneString);
		System.out.println(hospital.getHphoneString());
		hospitalService.add(hospital);
		return SUCCESS;
	}
   public String findpage(){
	   hospital.setHnumber(Integer.parseInt(hnumber));
	   ActionContext.getContext().getSession().put("aimNum",hnumber);
	   System.out.println(hnumber);
	return SUCCESS;   
   }
	/* �޸����ʿ���Ϣ �����޸�*/
	public String update() {
		/*�ٻ�ȡ�û���Ϣ*/
		//��ȡsession��ֵ
     	/*System.out.println(ServletActionContext.getRequest().getSession().getAttribute("aimNum"));	*/
     	hospital.setHnumber(Integer.parseInt( ServletActionContext.getRequest().getSession().getAttribute("aimNum").toString()));
     	hospital.setHaddress(haddress);
     	hospital.setHname(hname);
     	hospital.setHowner(howner);
     	hospital.setHphoneString(hphoneString);
	     hospitalService.updateHos(hospital);
		return SUCCESS;
	}

	/* ��ȡȫ�����ʿ���Ϣ */
	public String getAll() {
		 newlist = hospitalService.getAll();
		return SUCCESS;
	}
	/*ɾ�����ʿ���Ϣ*/
	public String delete(){
		hospital.setHnumber(Integer.parseInt(hnumber));
		hospitalService.deleteByNum(hospital);
		return SUCCESS;
	}
	
	/**
	 * @return newlist
	 */
	public List<Hospital> getNewlist() {
		return newlist;
	}
}
