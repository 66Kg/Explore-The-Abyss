/**
 * 
 */
package com.Memmsys.action;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.Memmsys.database.Depot;
import com.Memmsys.database.Instorage;
import com.Memmsys.database.Material;
import com.Memmsys.serviceinterfc.DepotService;
import com.Memmsys.serviceinterfc.InstorageService;
import com.Memmsys.serviceinterfc.MateService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author wangyao
 * 
 */
@SuppressWarnings("serial")
public class InstorAction extends ActionSupport {
	Material material=new Material();
	Instorage instorage=new Instorage();
	Depot depot=new Depot();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
   
	private String mid;
	private String number;
	private String mname;
	private String mtype;
	private String mbirth;
	private String muyear;

	private String innum;
	private String intime;
	private String inaccount;
	private String inperson;
	private String allmoney;
	
	//�����ϲ���
	private String oldnum;

	private MateService mateService;
	private InstorageService instorageService;
	private DepotService depotService;

	private List<Material> list;
	private List<Instorage>inlist;
	private List<Map<String, Object>> dataList;
	/**
	 * @return number
	 */
	public String getNumber() {
		return number;
	}
	/**
	 * @param number Ҫ���õ� number
	 */
	public void setNumber(String number) {
		this.number = number;
	}
	/**
	 * @return mname
	 */
	public String getMname() {
		return mname;
	}
	/**
	 * @param mname Ҫ���õ� mname
	 */
	public void setMname(String mname) {
		this.mname = mname;
	}
	/**
	 * @return mtype
	 */
	public String getMtype() {
		return mtype;
	}
	/**
	 * @param mtype Ҫ���õ� mtype
	 */
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}
	/**
	 * @return mbirth
	 */
	public String getMbirth() {
		return mbirth;
	}
	/**
	 * @param mbirth Ҫ���õ� mbirth
	 */
	public void setMbirth(String mbirth) {
		this.mbirth = mbirth;
	}
	/**
	 * @return muyear
	 */
	public String getMuyear() {
		return muyear;
	}
	/**
	 * @param muyear Ҫ���õ� muyear
	 */
	public void setMuyear(String muyear) {
		this.muyear = muyear;
	}
	/**
	 * @return innum
	 */
	public String getInnum() {
		return innum;
	}
	/**
	 * @param innum Ҫ���õ� innum
	 */
	public void setInnum(String innum) {
		this.innum = innum;
	}
	/**
	 * @return intime
	 */
	public String getIntime() {
		return intime;
	}
	/**
	 * @param intime Ҫ���õ� intime
	 */
	public void setIntime(String intime) {
		this.intime = intime;
	}
	/**
	 * @return inaccount
	 */
	public String getInaccount() {
		return inaccount;
	}
	/**
	 * @param inaccount Ҫ���õ� inaccount
	 */
	public void setInaccount(String inaccount) {
		this.inaccount = inaccount;
	}
	/**
	 * @return inperson
	 */
	public String getInperson() {
		return inperson;
	}
	/**
	 * @param inperson Ҫ���õ� inperson
	 */
	public void setInperson(String inperson) {
		this.inperson = inperson;
	}
	/**
	 * @return allmoney
	 */
	public String getAllmoney() {
		return allmoney;
	}
	/**
	 * @param allmoney Ҫ���õ� allmoney
	 */
	public void setAllmoney(String allmoney) {
		this.allmoney = allmoney;
	}
	/**
	 * @param mateService Ҫ���õ� mateService
	 */
	public void setMateService(MateService mateService) {
		this.mateService = mateService;
	}
	/**
	 * @param instorageService Ҫ���õ� instorageService
	 */
	public void setInstorageService(InstorageService instorageService) {
		this.instorageService = instorageService;
	}
	/*����������*/
	public String add(){
		//����������Ϣ��
		material.setMname(mname);
		material.setMtype(mtype);
		material.setNumber(Integer.parseInt(number));
		Date date;
		try {
			date = sdf.parse(mbirth);
			material.setMbirth(date);
			date=sdf.parse(muyear);
			material.setMuyear(date);
		} catch (ParseException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		material.setMaccount(Integer.parseInt(inaccount));
		//���������Ϣ��
		instorage.setInnum(Integer.parseInt(innum));
		instorage.setInaccount(Integer.parseInt(inaccount));
		instorage.setAllmoney(Long.parseLong(allmoney));
		Date dt;
		try {
			dt = sdf.parse(intime);
			instorage.setIntime(dt);
		} catch (ParseException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		instorage.setInperson(inperson);
		//�����洢
		instorage.setMaterial(material);	
		instorageService.add(instorage);
		
		//������
		//��ѯ������Ϊ���򴴽���һ������
		List<Depot>list=depotService.getAllDepot();
		if (list.size()==0) {
			depot.setDname(mname);
			depot.setDaccount(Integer.parseInt(inaccount));
			depot.setDtype(mtype);
			Date datedp;
			try {
				datedp = sdf.parse(intime);
				depot.setDtime(datedp);
			} catch (ParseException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			depotService.add(depot);				
		}
		else {
			List< Depot>lDepots= depotService.getByName(mname);		  
			if(lDepots.size()!=0){
				int newAccount=Integer.parseInt(inaccount)+lDepots.get(0).getDaccount();
				depot.setDname(mname);
				depot.setDaccount(newAccount);
				depotService.updateDepot(depot);				
			}
			else {
				depot.setDname(mname);
				depot.setDaccount(Integer.parseInt(inaccount));
				depot.setDtype(mtype);
				Date datesDate=new Date();
				depot.setDtime(datesDate);
				depotService.add(depot);							
			}
		}
		material.setDepot(depot);
		return SUCCESS;
	}
	//��ѯ�����Ϣ����
	public String getAll(){
		inlist=instorageService.getAll();
		list=mateService.getAllInstor();
		dataList = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < inlist.size(); i++) {
			Instorage instorage=inlist.get(i);
			Material material=list.get(i);
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("mid", material.getmId());
			map.put("mname", material.getMname());
			map.put("number", material.getNumber());
			map.put("mtype", material.getMtype());
			map.put("mbirth", material.getMbirth());
			map.put("muyear", material.getMuyear());
			map.put("innum", instorage.getInnum());
			map.put("intime", instorage.getIntime());
			map.put("inaccount", instorage.getInaccount());
			map.put("inperson", instorage.getInperson());
			map.put("allmoney", instorage.getAllmoney());
			dataList.add(map);	
		}
		return SUCCESS;		
	}
	//ָ���޸�Ŀ��
	public String aimed() throws UnsupportedEncodingException{
		String name=new String(mname.getBytes("ISO-8859-1"),"utf-8");
		ActionContext.getContext().getSession().put("mname",name);
		ActionContext.getContext().getSession().put("inaccount",inaccount);
		ActionContext.getContext().getSession().put("innum",innum);
		return SUCCESS;	
	}
	//�޸������Ϣ�����¿�
	public String update(){
		//�������ʱ�
		int id=instorageService.getMid(Integer.parseInt(ActionContext.getContext().getSession().get("innum").toString()));
    	material.setmId(id);
		material.setMtype(mtype);
		material.setNumber(Integer.parseInt(number));
		Date date;
		try {
			date = sdf.parse(mbirth);
			material.setMbirth(date);
			date=sdf.parse(muyear);
			material.setMuyear(date);
		} catch (ParseException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		material.setMaccount(Integer.parseInt(inaccount));
	     //���������Ϣ��
		instorage.setInnum(Integer.parseInt(ActionContext.getContext().getSession().get("innum").toString()));
		instorage.setInaccount(Integer.parseInt(inaccount));
		instorage.setAllmoney(Long.parseLong(allmoney));
		Date dt;
		try {
			dt = sdf.parse(intime);
			instorage.setIntime(dt);
		} catch (ParseException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		instorage.setInperson(inperson);
		//����ͳ�Ʊ�	
	    List<Depot>depots=depotService.getByName(ActionContext.getContext().getSession().get("mname").toString());
		if (Integer.parseInt((String) ActionContext.getContext().getSession().get("inaccount"))>Integer.parseInt(inaccount)) {
			int clnum=Integer.parseInt((String) ActionContext.getContext().getSession().get("inaccount"))-Integer.parseInt(inaccount);
		    int newaccount= depots.get(0).getDaccount()-clnum;		
		    depot.setDaccount(newaccount);
		}
		else {
			int clnum=Integer.parseInt(inaccount)-Integer.parseInt((String) ActionContext.getContext().getSession().get("inaccount"));
			 int newaccount= depots.get(0).getDaccount()+clnum;
			 depot.setDaccount(newaccount);
		}
	       depot.setDname(ActionContext.getContext().getSession().get("mname").toString());	    
		    depot.setDtype(mtype);
		    Date datedp=new Date();
		    depot.setDtime(datedp);	
		mateService.updateById(material,instorage,depot);
		return SUCCESS;
	}
	/**
	 * @return list
	 */
	public List<Material> getList() {
		return list;
	}
	/**
	 * @return inlist
	 */
	public List<Instorage> getInlist() {
		return inlist;
	}
	/**
	 * @return dataList
	 */
	public List<Map<String, Object>> getDataList() {
		return dataList;
	}
	/**
	 * @param depotService Ҫ���õ� depotService
	 */
	public void setDepotService(DepotService depotService) {
		this.depotService = depotService;
	}
	/**
	 * @return oldnum
	 */
	public String getOldnum() {
		return oldnum;
	}
	/**
	 * @param oldnum Ҫ���õ� oldnum
	 */
	public void setOldnum(String oldnum) {
		this.oldnum = oldnum;
	}
	/**
	 * @return mid
	 */
	public String getMid() {
		return mid;
	}
	/**
	 * @param mid Ҫ���õ� mid
	 */
	public void setMid(String mid) {
		this.mid = mid;
	}
}
