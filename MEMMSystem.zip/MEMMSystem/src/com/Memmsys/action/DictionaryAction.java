/**
 * 
 */
package com.Memmsys.action;

import java.io.UnsupportedEncodingException;
import java.util.List;

import com.Memmsys.database.Depot;
import com.Memmsys.database.Dictionary;
import com.Memmsys.serviceinterfc.DictionaryService;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author wangyao
 * 
 */
@SuppressWarnings("serial")
public class DictionaryAction extends ActionSupport {
	Dictionary dictionary = new Dictionary();
    Depot depot=new Depot();
	private String ename;
	private String eename;
	private String eground;
	private String euse;
	private String espec;
	private String epeople;
	private String ebadside;

	private String dname;

	private DictionaryService dictionaryService;

	private List<Dictionary> datalist;

	// �ж��Ƿ��дʵ�
	public String judge() throws UnsupportedEncodingException {
		String name = new String(dname.getBytes("ISO-8859-1"), "utf-8");
		List<Dictionary> list = dictionaryService.getByName(name);
		if (list.size() > 0) {
			datalist = list;
			return SUCCESS;
		} else {
			ActionContext.getContext().getSession().put("dname", name);
			return "nodata";
		}
	}

	// ���Ӵʵ���Ϣ
	public String add() throws UnsupportedEncodingException {
		dictionary.setEname(ActionContext.getContext().getSession()
				.get("dname").toString());
		String[] strArray = {eename, eground, ebadside, epeople, espec, euse};
		for (int i = 0; i < strArray.length; i++) {
			if ("".equals(strArray[i])) {
				strArray[i] = "δ¼��";
			}	
		}
		dictionary.setEename(strArray[0]);
		dictionary.setEground(strArray[1]);
		dictionary.setEbadside(strArray[2]);
		dictionary.setEpeople(strArray[3]);
		dictionary.setEspec(strArray[4]);
		dictionary.setEuse(strArray[5]);
		dictionaryService.add(dictionary);
		dictionary.setDepot(depot);
		return SUCCESS;
	}

	// ��λĿ��
	public String topage() throws UnsupportedEncodingException {
		String name = new String(ename.getBytes("ISO-8859-1"), "utf-8");
		ActionContext.getContext().getSession().put("ename", name);
		return SUCCESS;
	}

	// �޸Ĵʵ���Ϣ
	public String update() {
		dictionary.setEname(ActionContext.getContext().getSession()
				.get("ename").toString());
		dictionary.setEename(eename);
		dictionary.setEground(eground);
		dictionary.setEbadside(ebadside);
		dictionary.setEpeople(epeople);
		dictionary.setEspec(espec);
		dictionary.setEuse(euse);
		dictionaryService.updateByName(dictionary);
		return SUCCESS;
	}

	/**
	 * @param dictionaryService
	 *            Ҫ���õ� dictionaryService
	 */
	public void setDictionaryService(DictionaryService dictionaryService) {
		this.dictionaryService = dictionaryService;
	}

	/**
	 * @return ename
	 */
	public String getEname() {
		return ename;
	}

	/**
	 * @param ename
	 *            Ҫ���õ� ename
	 */
	public void setEname(String ename) {
		this.ename = ename;
	}

	/**
	 * @return eename
	 */
	public String getEename() {
		return eename;
	}

	/**
	 * @param eename
	 *            Ҫ���õ� eename
	 */
	public void setEename(String eename) {
		this.eename = eename;
	}

	/**
	 * @return eground
	 */
	public String getEground() {
		return eground;
	}

	/**
	 * @param eground
	 *            Ҫ���õ� eground
	 */
	public void setEground(String eground) {
		this.eground = eground;
	}

	/**
	 * @return euse
	 */
	public String getEuse() {
		return euse;
	}

	/**
	 * @param euse
	 *            Ҫ���õ� euse
	 */
	public void setEuse(String euse) {
		this.euse = euse;
	}

	/**
	 * @return espec
	 */
	public String getEspec() {
		return espec;
	}

	/**
	 * @param espec
	 *            Ҫ���õ� espec
	 */
	public void setEspec(String espec) {
		this.espec = espec;
	}

	/**
	 * @return epeople
	 */
	public String getEpeople() {
		return epeople;
	}

	/**
	 * @param epeople
	 *            Ҫ���õ� epeople
	 */
	public void setEpeople(String epeople) {
		this.epeople = epeople;
	}

	/**
	 * @return ebadside
	 */
	public String getEbadside() {
		return ebadside;
	}

	/**
	 * @param ebadside
	 *            Ҫ���õ� ebadside
	 */
	public void setEbadside(String ebadside) {
		this.ebadside = ebadside;
	}

	/**
	 * @return dname
	 */
	public String getDname() {
		return dname;
	}

	/**
	 * @param dname
	 *            Ҫ���õ� dname
	 */
	public void setDname(String dname) {
		this.dname = dname;
	}

	/**
	 * @return datalist
	 */
	public List<Dictionary> getDatalist() {
		return datalist;
	}

}
