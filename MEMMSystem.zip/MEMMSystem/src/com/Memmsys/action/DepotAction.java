/**
 * 
 */
package com.Memmsys.action;

import java.util.List;

import com.Memmsys.database.Depot;
import com.Memmsys.serviceinterfc.DepotService;
import com.opensymphony.xwork2.ActionSupport;

/**
 * @author wangyao
 *
 */
@SuppressWarnings("serial")
public class DepotAction extends ActionSupport{
   Depot depot=new Depot();
   private DepotService depotService;
   private List<Depot>list;
/**
 * @param depotService Ҫ���õ� depotService
 */
public void setDepotService(DepotService depotService) {
	this.depotService = depotService;
}
/**
 * @return list
 */
public List<Depot> getList() {
	return list;
}
public String getAll(){
	list=depotService.getAll();
	return SUCCESS;
}
}
