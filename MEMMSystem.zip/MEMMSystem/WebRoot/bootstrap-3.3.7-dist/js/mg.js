/**
 * Created by wangyao on 2017/5/1.
 */
function hosadd(){
    var a="hisatory/managehosadd.jsp"
    document.getElementById("myframe").src=a
}
function hossel(){
    var a="hos_selall"
    document.getElementById("myframe").src=a
}
function  hosmod(){
    var a="hos_mod"
    document.getElementById("myframe").src=a
}
function hosmate(){
    var a="hisatory/manage_hosmate.jsp"
    document.getElementById("myframe").src=a
}
function matein(){
    var a="instorage/manage_matein.jsp"
    document.getElementById("myframe").src=a
}
function  mateinsel(){
    var a="instor_getAll"
    document.getElementById("myframe").src=a
}
function inmod(){
    var a="instorage/manage_mateinmod.jsp"
    document.getElementById("myframe").src=a
}
function odsel(){
    var a="over_mate"
    document.getElementById("myframe").src=a
}
function mateout(){
    var a="outstorage/manage_mateout.jsp"
    document.getElementById("myframe").src=a
}
function mateoutsel(){
    var a="out_sel"
    document.getElementById("myframe").src=a
}
function outdel(){
    var a="outstorage/manage_mateoutdel.jsp"
    document.getElementById("myframe").src=a
}
function matesel(){
    var a="mate_sel"
    document.getElementById("myframe").src=a
}
function mateadd(){
    var a="material/manage_mateadd.jsp"
    document.getElementById("myframe").src=a
}
function matemod(){
    var a="mate_findpage"
    document.getElementById("myframe").src=a
}